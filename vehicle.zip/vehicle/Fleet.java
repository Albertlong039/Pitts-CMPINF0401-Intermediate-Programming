public class Fleet{
	
	public static void main(String[] args){
		Vehicle car1 = new Vehicle(); // create an OBJECT instance of our Vehicle class
		car1.model = "Mustang";
		car1.weight = 2900;
		car1.color = "Silver";
		car1.year = 2020;
		car1.mpg = 27.8;
		car1.stats();
		
	}
	
	
	
}