import java.util.*;
public class Fleet{
	
	public static void main(String[] args){
		Vehicle car1 = new Vehicle(); //Using base constructor, just makes a Vehicle object for us to use and nothing else
		car1.setModel("Mustang");
		car1.setWeight(2900);
		car1.setColor("Silver");
		car1.setYear(2020);
		car1.setMPG(27.8);
		car1.stats();
		
		//Lets test out data hiding logic, lets make another Vehicle object
		
		Vehicle car2 = new Vehicle("Mustang",2750,"Blue",30.0,2021); //Using Overload Constructor so we can create AND define our object in 1 simpler line
		car2.stats();
		
		
		Car car3 = new Car();
		car3.setModel("Mustang");
		car3.setWeight(2900);
		car3.setColor("Red");
		car3.setYear(2016);
		car3.setMPG(27.8);
		car3.setSeating(4);
		car3.stats();
		
		System.out.println("Now we will go through all objects created from the superclass Vehicle");
		
		ArrayList<Vehicle> cars = new ArrayList<Vehicle>(); // create an arraylist of our objects we create from the Vehicle class
		// Each vehicle with ALL of its methods and datafields will be stored in each element of our arraylist. Remember an ArrayList stores every value as an object instead of a primitive like a normal array
		
		cars.add(car1);
		cars.add(car2);
		cars.add(car3); //We can add an object created by the subclass(Car) of the superclass(Vehicle) to an Arraylist of Vehicle because Car is a child of the parent Vehicle class.
		for(Vehicle car : cars)
		{
			car.stats();
		}
		
		
		// You can see how 2 constructors work to do the same thing but in 2 different ways
		
		
		
		
	}
	
	
	
}