import java.util.*;
import java.io.*;
public class Lab4
{
	public static void main(String[] args) throws Exception
	{
		if(args.length<1)
		{
			System.out.println("USAGE:java Lab4 jumbles.txt");
			System.exit(0);
		}
		ArrayList<String> words=new ArrayList<String>();
		BufferedReader infile=new BufferedReader(new FileReader(args[0]));
		while(infile.ready())
		{
			String line=infile.readLine();
			words.add(line);
		}
		infile.close();
		Collections.sort(words);
		for (String word:words)
		{
			System.out.println(word+" "+canonical(word));
		}
	}
	static String canonical(String word)
	{
			char[] arr=word.toCharArray();
			Arrays.sort(arr);
			return new String(arr);
	}

}