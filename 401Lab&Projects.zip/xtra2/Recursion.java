import java.io.*;
public class Recursion
{
	public static void main( String[] args )
	{

		int rows = 5;
		System.out.format("%d row triangle tree contains %d stars\n", rows, triStars( rows ) );

		int number = 12345;
		System.out.format("sum of digits in %d = %d\n", number, sumDigits( number ) );

		number = 713274772;
		System.out.format("%d occurances of digit 7 in %d\n", count7s(number), number );

		number = 82338828;
		System.out.format("%d occurances** of digit 8 in %d\n", count8s(number), number );

		int base=2,exponent=8;
		System.out.format("%d to the power %d = %d\n", base, exponent, powerN(base,exponent) );

		// perturb values as need to test on an unsorted array
		int[] array = { 7, 8, 12, 20, 21, 22, 37, 41, 55, 60, 65, 74, 83, 84, 87 };
		int startingAt=0;
		boolean isSorted = isSorted( array, startingAt, array.length );
		System.out.print( "array: ");
		for ( int i=0 ; i<array.length ; ++i ) System.out.print( array[i] + " " );
		if (isSorted)
			System.out.println(" is SORTED" );
		else
			System.out.println(" is NOT SORTED" );

		String s = "stanleyyelnats"; // try with several differnt values that are or not palindromes
		if ( isPalindrome( s, 0, s.length()-1 ) )
			System.out.format("%s IS a palindrome\n", s );
		else
			System.out.format("%s NOT a a palindrome\n", s ); // should be %s NOT a plaindrome
	} // END MAIN

	// count stars in a triangle using # of rows as input
	static int triStars(int rows)
	{	
		int temp=rows;
		if(temp>=1)
		{
			temp=triStars(temp-1)+temp;

		}
		return temp;
	}
	// given a number return the sum of the digits
	static int sumDigits(int n)
	{	
		int sum=n%10;
		n=n/10;
		if (n>0)
		{
			sum=sum+sumDigits(n);
		}
		return sum;
	}
	// given a number compute the number of 7's in that number
	static int count7s(int n)
	{	
		int i=n%10;
		int sum=0;
		if (n>0)
		{
			if (i==7)
			{
				sum=1;
			}
			sum=sum+count7s(n/10);//xiangbi shangyige youmeiyou dedao yao+deliang
		}
		return sum;

	}
	// given a number count the number of 8 but if an 8 has another 8 to its immdiate left count it as 2
	// the number 8802388 will return a count of 6
	static int count8s(int n)
	{	return 0; // JUST TO MAKE IT COMPILE
	}
	//compute base to the power n
	static int powerN(int base, int n)
	{	
		if (n>=1)
		{
			int multi=base*powerN(base,n-1);
			return multi;
		}
		else if (n==0)
		return 1;
		else 
		{
			int multi=base*powerN(base,n+1);
			return multi;
		}	
	}
	// return true only if the array is sorted
	static boolean isSorted(int array[], int i, int count )
	{	
		if(i<count-1)
		{
			if (array[i]<array[i+1])
			return isSorted(array, i+1,count);
		return false;
		}
		return true;

	}
	static boolean isPalindrome(String s, int lo, int hi )
	{
		if (lo>=hi)
			return true;
		if (s.charAt(lo)==s.charAt(hi))
			return isPalindrome(s,lo+1,hi-1);
		else
		return false;
	}
} // END CLASS


