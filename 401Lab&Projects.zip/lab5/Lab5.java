/*  MY NAME=Qingshi Sun MY ID=QIS30
		
		CORRECT OUTPUT 5 PTS	 CORRECT EXPLANATION 2 POINTS
--------------------------------------------------------------------------
MYSTERY #1:  (1) <951413>	(2) <Print each digit of a number from the last one to the first one>
MYSTERY #2:  (1) <23>	(2) <return the sum of all the digits of the given number>
MYSTERY #3:  (1) <23>	(2) <return the sum of all the digits of the given number>
MYSTERY #4:  (1) <false>	(2) <Test whether the numbers of the array is in ascending order; it so, return ture;otherwise return false>
MYSTERY #5:  (1) <5 4 3 2 1>	(2) <print all the positive integers less than or equal to the given number from big to small>
MYSTERY #6:  (1) <1 2 3 4 5>	(2) <print all the positive integers less than or equal to the given number from small to big>
MYSTERY #7:  (1) <5 4 3 2 1 1 2 3 4 5>	(2) <print all the positive integers less than or equal to the given number from big to small and from small to big>
*/