import java.io.*;
import java.util.*;

public class LinkedList
{
	private Node head;  // pointer to the front (first) element of the list

	public LinkedList()
	{
		head = null; // compiler does this anyway. just for emphasis
	}

	// COPY ALL NODES FROM OTHER LIST INTO THIS LIST. WHEN COMPLETED THIS LIST IDENTICAL TO OTHER
	public LinkedList( LinkedList other )
	{
		head = other.head; // YOU ABSOLUTLEY MUST CHANGE THIS. THIS IS A SHALLOW COPY :(
	}

	// LOAD LINKED LIST FORM INCOMING FILE
	
	public LinkedList( String fileName ) 
	{
		try 
		{
			BufferedReader infile = new BufferedReader( new FileReader( fileName ) );
			while ( infile.ready() )
			{  
				insertAtTail( infile.readLine() );  
			}
			infile.close();
		}
		catch( Exception e )
		{
			System.out.println( "FATAL ERROR CAUGHT IN C'TOR: " + e );
			System.exit(0);
		}
	}	
	
	//-------------------------------------------------------------

	// inserts new elem at front of list - pushing old elements back one place

	public void insertAtFront(String data)
	{
		head = new Node(data,head);
	}

	// we use toString as our print

	public String toString()
	{
		String toString = "";

		for (Node curr = head; curr != null; curr = curr.getNext())
		{
			toString += curr.getData();		// WE ASSUME OUR T TYPE HAS toString() DEFINED
			if (curr.getNext() != null)
				toString += " -> ";
		}

		return toString + "\n";
	}

	// ########################## Y O U   W R I T E    T H E S E    M E T H O D S ########################

	// TACK A NEW NODE (CABOOSE) ONTO THE END OF THE LIST
	public void insertAtTail(String data)
	{
	if ( head == null ) insertAtFront( data );
		
		//ELSE GET A REF TO THE VERY LAST NODE AND HANG IT OFF THE LAST NODE'S NEXT REF
		else 
		{
			Node newNode = new Node(data);
			Node curr = head;
			while ( curr.getNext() != null )
			{
				curr = curr.getNext();
			}
			curr.setNext(newNode);
		}
	}

	// OF COURSE MORE EFFICIENT TO KEEP INTERNAL COUNTER BUT YOU COMPUTE IT DYNAMICALLY WITH A TRAVERSAL LOOP
	public int size()
	{	int count=0;
		for(Node curr= head;curr!=null;curr=curr.getNext())//while(curr.getNext()!=null) not in the end
			count++;
			
		return count; 
	}
	public boolean contains( String key )
	{
		return ( search( key ) != null ); // REPLACE WITH CALL TO SEARCH. IF NULL RETURN FALSE ELSE RETURN TRUE
	}

	
	public Node search( String key )
	{
		if ( head == null ) return null;
		else
		{
			Node curr = head;
			while ( curr != null )
			{
				if ( curr.getData().equals(key)  )
					return curr;
				else
				{
					curr = curr.getNext();
				}
			}
			return curr;
		}
	}

} //EOF