/*
	ExceptionsDemo5.java

	- illustrates manually throwing an Exception

*/
import java.io.*;
import java.util.*;

public class ExceptionsDemo5
{
	public static void main( String args[] )
	{

		String name;
		Scanner kbd = new Scanner( System.in );
		System.out.print( "Enter your first name: ");
		name = kbd.next();
		try
		{
			if ( name.length() < 2 ) throw new Exception( "Invalid name:" + name + " must be at least 2 chars long");
			
		}
		catch (Exception e)
		{
			System.out.println( e );
			System.exit( 0 );
		}
		System.out.println( "Thank you " + name );
		

		
	} //END main
} //EOF