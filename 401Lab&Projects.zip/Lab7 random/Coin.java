/*
	Coin.java THIS IS THE ONLY FILE YOU HAND IN
	THERE IS NO MAIN METHOD IN THIS CLASS!
*/
import java.util.Random;
public class Coin
{
	private int head=1;
	private int tail=0;
	private Random r;
	private int i=0;
	private int j=0;


	public Coin(int Seed)
	{
		r=new Random(Seed);
	}

	public String flip()
	{
		
		int t=r.nextInt(2);
		if (t==head)
		{
		setNumHeads(getNumHeads()+1);
		return "H";
		}
		else 
		{
		setNumTails(getNumTails()+1);
		return "T";
		}
	}

	public int getNumHeads()
	{
		return i;
	}

	public int getNumTails()
	{
		return j;
	}

	public void setNumHeads(int n)
	{
		i=n;
	}

	public void setNumTails(int m)
	{
		j=m;
	}

	public void reset()
	{
		setNumTails(0);
		setNumHeads(0);
	}





} // END COIN CLASS