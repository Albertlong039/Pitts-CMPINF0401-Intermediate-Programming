import java.io.*;
import java.util.*;

public class LinkedList
{
	private Node head;  // pointer to the front (first) element of the list

	public LinkedList()
	{
		head = null; // compiler does this anyway. just for emphasis
	}

	// LOAD LINKED LIST FORM INCOMING FILE	
	public LinkedList( String fileName, boolean orderedFlag )
	{
		head=null;
		try
		{
			BufferedReader infile = new BufferedReader( new FileReader( fileName ) );
			while ( infile.ready() )
			{
				if (orderedFlag)
					insertInOrder( infile.readLine() );  // WILL INSERT EACH ELEM INTO IT'S SORTED POSITION
				else
					insertAtTail( infile.readLine() );  // TACK EVERY NEWELEM ONTO END OF LIST. ORIGINAL ORDER PRESERVED
			}
			infile.close();
		}
		catch( Exception e )
		{
			System.out.println( "FATAL ERROR CAUGHT IN C'TOR: " + e );
			System.exit(0);
		}
	}

	//-------------------------------------------------------------

	public void insertAtFront( String data)
	{
		head = new Node(data,head);
	}

	public String toString()
	{
		String toString = "";
		for (Node curr = head; curr != null; curr = curr.next)
		{	toString += curr.data;		// WE ASSUME OURTYPE HAS toString() DEFINED
			if ( (curr.next) != null )
				toString += " ";
		}
		return toString;
	}

	// ######################## Y O U   W R I T E   T H E S E    M E T H O D S #####################

	public int size() 
	{
		int count=0;
		for (Node curr=head;curr!=null;curr=curr.next)
		{
			count++;
		}
		return count;

	}

	public boolean empty()
	{
		return (size()>0); 
	
	}

	public boolean contains( String key )
	{
		return (search(key)!=null);
	}

	public Node search( String key )
	{
		if (head==null) return null;
		else
		{
			Node curr=head;
			while(curr!=null)
			{
				if(key.equals(curr.data))
					return curr;
				curr=curr.next;
			}
			return curr;
		}
	}

	public void insertAtTail(String  data) // TACK A NEW NODE (CABOOSE) ONTO THE END OF THE LIST
	{
		if ( head == null ) insertAtFront( data );
		
		//ELSE GET A REF TO THE VERY LAST NODE AND HANG IT OFF THE LAST NODE'S NEXT REF
		else 
		{
			Node newNode = new Node(data,null);
			Node curr = head;
			while ( curr.next != null )
			{
				curr = curr.next;
			}
			curr.next=newNode;
		}
	}

	public void insertInOrder( String  data) // PLACE NODE IN LIST AT ITS SORTED ORDER POSTIOPN
	{
		Comparable comData=(Comparable)data;
		if(head==null||comData.compareTo(head.data)<0) 
		{
			insertAtFront(data);
			return;
		}

		Node curr = head;
		while(curr.next!=null&&comData.compareTo(curr.next.data)>0)
		{
			curr=curr.next;
		}
		curr.next=new Node(data,curr.next);
		return;
	}
	
	public boolean remove( String key) // FIND/REMOVE 1st OCCURANCE OF A NODE CONTAINING KEY
	{

		if (empty()) return false;
		if(key.equals(head.data)) 
			{
				removeAtFront();
			}
	
		Node curr = head;
		while(curr.next!=null&& curr.next.data.equals(key)!=true)
		{
			curr=curr.next;
		}
		if (curr.next==null) return false;
		curr.next=curr.next.next;
		return true;

	}

	public boolean removeAtTail( )	// RETURNS TRUE IF THERE WAS NODE TO REMOVE
	{
		Node curr = head;
	    if(empty()==true) return false;
	    if (head.next==null)
	    {
	    	removeAtFront();
	    	return true; 
	    }
        
		while(curr.next.next!=null)
		{
			curr=curr.next;
		}
		curr.next=null;
		return true;
	}

	public boolean removeAtFront() // RETURNS TRUE IF THERE WAS NODE TO REMOVE
	{

		if (head!=null)
		{
			head=head.next;
								
			return true;
		}
		return false; 
	}

	public LinkedList union( LinkedList other )
	{
		LinkedList union = new LinkedList();
		
		for(Node thisCurr = this.head; thisCurr!= null; thisCurr = thisCurr.next)///difference node<T> and node: use node<T>：full name T is the data type inside the node
			{
				union.insertInOrder(thisCurr.data);///difference between (insertAtTail(thisCurr.data))===call "this "
			}

	
		for(Node otherCurr = other.head; otherCurr!= null; otherCurr = otherCurr.next)
		{
			if (!union.contains(otherCurr.data)) union.insertInOrder(otherCurr.data);
		}
		
		return  union; 
	}
	
	@SuppressWarnings("unchecked")
	public LinkedList inter( LinkedList other )
	{
		LinkedList inter = new LinkedList();
		for(Node thisCurr = this.head; thisCurr!= null; thisCurr = thisCurr.next)
			{
				for(Node otherCurr = other.head; otherCurr!= null; otherCurr = otherCurr.next)
					{
						if (thisCurr.data.equals(otherCurr.data)) inter.insertInOrder(otherCurr.data);
					}
			}

		return  inter; 
	}

	public LinkedList diff( LinkedList other )
	{
		LinkedList diff = new LinkedList();
		for(Node thisCurr = this.head; thisCurr!= null; thisCurr = thisCurr.next)
			{
				if (!other.contains(thisCurr.data)) 
					diff.insertInOrder(thisCurr.data);
			}
		return  diff; 
	}

	public LinkedList xor( LinkedList other )
	{
		return this.union(other).diff(this.inter(other));
	}

} //END LINKEDLIST CLASS

class Node
{ 
	String data;
	Node next;  
	Node ( String data, Node next )
	{ 
		this.data = data;
		this.next = next;
	}
} // END NODE CLASS