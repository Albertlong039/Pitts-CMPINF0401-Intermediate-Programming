import java.util.*;
import java.io.*;
public class Jumbles
{
	public static void main(String args[]) throws Exception
	{
		if (args.length<1)
		{
			System.out.println("USAGE:Dictionary.txt Jumbles.txt");
			System.exit(0);
		}
		BufferedReader infile=new BufferedReader(new FileReader(args[0]));
		ArrayList<String> pairs=new ArrayList<String>();
		while (infile.ready())
		{
			String dWord=infile.readLine();
			String tem=cononical(dWord);
			pairs.add(tem+" "+dWord);
		}
		infile.close();
		Collections.sort(pairs);
		
		ArrayList<String> dCanons=new ArrayList<String>();
		ArrayList<String> dWords=new ArrayList<String>();
		for(String line:pairs)
		{
			String[] pair=line.split("\\s+");
			dCanons.add(pair[0]);
			dWords.add(pair[1]);
		}
		BufferedReader infile1=new BufferedReader(new FileReader(args[1]));
		ArrayList<String> jWords=new ArrayList<String>();
		while(infile1.ready())
		{
			String word=infile1.readLine();
			jWords.add(word);
		}
		infile1.close();
		Collections.sort(jWords);
		
		for (String jword:jWords)
		{
			System.out.print(jword);
			String jCanon=cononical(jword);
			int index=Collections.binarySearch(dCanons,jCanon);
			if(index>=0)
			{
				int a=index;
				int b=0;
				while(b==0&&a>0)
					{
						a=a-1;
						b=jCanon.compareTo(dCanons.get(a));
					}
				if (b!=0)
					a=a+1;
								
				int c=index;
				int d=0;

				while(d==0&&c<dCanons.size()-1)
				{
					c=c+1;
					d=jCanon.compareTo(dCanons.get(c));
				}
				if(d!=0)
				c=c-1;
				for(int i=a;i<=c;i++)
				{
					System.out.print(" "+dWords.get(i));
				}
			}
			System.out.println();
		}
		

	}
	static String cononical(String word)
	{
        char[] arr=word.toCharArray();
        Arrays.sort(arr);
		return new String(arr);
	}
}